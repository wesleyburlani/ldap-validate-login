var config = {
    host: env.HOST,
    user: {
        baseDn: env.USER_BASEDN,
    },
    admin: {
        entryDn: env.ADMIN_ENTRYDN,
        passwd: env.ADMIN_PASSWD,
    },
}

module.exports = config;